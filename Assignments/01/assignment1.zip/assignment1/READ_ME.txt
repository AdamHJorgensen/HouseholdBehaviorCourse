This project folder provides the solutions and figures to Assignment 1 in the course Household Behavior over the Life Cycle at KU 2023.

Author: Adam Hallengreen Jørgensen

Structure:
 - assignment_1.pdf contains the answer to the assignment
 - assignment1.ipynb runs the code and generates the results
 - DynLaborFertModel.py contains the model
 - tools.py contains some functions for calculating elasticities and making plots
 - figures folder contain all figures
 - models folder contain all saved models